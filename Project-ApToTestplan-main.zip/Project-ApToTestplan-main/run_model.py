import json
import os
import subprocess
import schedule
import time
import logging
import sys
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("model_scheduler.log"),
        logging.StreamHandler(sys.stdout)  # Make sure output is visible
    ]
)
logger = logging.getLogger()

def check_and_run_model():
    """Check if EFR tag has changed and run the model if needed"""
    try:
        # Paths
        current_dir = os.path.dirname(os.path.abspath(__file__))
        last_tag_json = os.path.join(current_dir, "last_efr_tag.json")
        efr_json = "/auto/violet/cron_efr_data_for_aptoTest_plan/leatest_efr_details.json"

        # Load current efr_tag
        with open(efr_json) as f:
            data = json.load(f)
        current_tag = data.get("efr_tag")
        
        # Log current check
        logger.info(f"Checking EFR tag: {current_tag}")

        # Load last seen efr_tag from JSON (if exists)
        last_tag = None
        if os.path.exists(last_tag_json):
            with open(last_tag_json) as f:
                last_tag_data = json.load(f)
                last_tag = last_tag_data.get("efr_tag")

        # If tag changed, run your model and update the record
        if current_tag != last_tag:
            logger.info(f"EFR tag changed: {last_tag} -> {current_tag}. Running model...")
            
            # Update tag BEFORE running the model to prevent repeated runs if script fails
            with open(last_tag_json, "w") as f:
                json.dump({"efr_tag": current_tag, "last_run": datetime.now().isoformat(), "status": "running"}, f)
            
            # Log the start of model execution
            logger.info("About to execute code_1.py...")
            
            try:
                # Direct execution without capture to see output in real time
                # This approach will show progress as it happens
                cmd = [sys.executable, os.path.join(current_dir, "code_1.py")]
                logger.info(f"Running command: {' '.join(cmd)}")
                
                # Use Popen to get real-time output
                process = subprocess.Popen(
                    cmd,
                    stdout=sys.stdout,  # Direct output to console
                    stderr=sys.stderr   # Direct errors to console
                )
                
                # Wait for completion
                retcode = process.wait()
                
                # Update status based on return code
                if retcode == 0:
                    logger.info("code_1.py execution completed successfully")
                    with open(last_tag_json, "w") as f:
                        json.dump({"efr_tag": current_tag, "last_run": datetime.now().isoformat(), "status": "completed"}, f)
                else:
                    logger.error(f"code_1.py exited with code {retcode}")
                    with open(last_tag_json, "w") as f:
                        json.dump({"efr_tag": current_tag, "last_run": datetime.now().isoformat(), "status": f"failed-{retcode}"}, f)
                
            except Exception as e:
                logger.error(f"Error during code_1.py execution: {str(e)}")
                # Already updated tag earlier, so we don't repeat runs
        else:
            logger.info(f"EFR tag unchanged ({current_tag}). No action taken.")
            
    except Exception as e:
        logger.error(f"Error in check_and_run_model: {str(e)}")

if __name__ == "__main__":
    # Simple argument handling
    if len(sys.argv) > 1:
        if sys.argv[1] == "force":
            # Force a run by updating last_tag_json to an empty string
            current_dir = os.path.dirname(os.path.abspath(__file__))
            last_tag_json = os.path.join(current_dir, "last_efr_tag.json")
            with open(last_tag_json, "w") as f:
                json.dump({"efr_tag": ""}, f)
            logger.info("Forced run by resetting last tag")
    
    logger.info("Starting AP Test Plan model scheduler")
    
    # Schedule the job to run weekly (every Monday at 2 AM)
    schedule.every().monday.at("02:00").do(check_and_run_model)
    
    # Also run once immediately
    logger.info("Running initial check...")
    check_and_run_model()
    
    # Fixed: Log next scheduled run - proper handling of schedule.jobs which is a list
    if schedule.jobs:
        next_run = schedule.jobs[0].next_run
        logger.info(f"Next scheduled run: {next_run}")
    
    # Keep the script running
    try:
        while True:
            schedule.run_pending()
            time.sleep(3600)  
    except KeyboardInterrupt:
        logger.info("Scheduler stopped by user")